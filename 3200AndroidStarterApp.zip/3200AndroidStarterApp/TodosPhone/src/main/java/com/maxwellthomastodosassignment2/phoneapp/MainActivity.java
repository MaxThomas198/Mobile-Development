package com.maxwellthomastodosassignment2.phoneapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.databinding.ObservableArrayList;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.EditText;

import com.maxwellthomastodosassignment2.api.TodoAdapter;
import com.maxwellthomastodosassignment2.api.models.Todo;
import com.maxwellthomastodosassignment2.api.viewmodels.TodosViewModel;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView todosList = findViewById(R.id.todoList);
        TodosViewModel viewModel = new ViewModelProvider(this).get(TodosViewModel.class);

        TodoAdapter adapter = new TodoAdapter(viewModel.getTodos(), (todo) -> {
            Boolean changeState = !todo.completed;
            viewModel.updateTodo(todo.id, changeState);
        });

        todosList.setAdapter(adapter);
        todosList.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.save).setOnClickListener((view) -> {
            EditText taskEditText = findViewById(R.id.task);
            Log.d("Task", taskEditText.getText().toString());
            viewModel.addTodo(taskEditText.getText().toString());
        });
    }
}