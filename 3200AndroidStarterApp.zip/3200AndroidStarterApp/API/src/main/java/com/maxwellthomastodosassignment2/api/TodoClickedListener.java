package com.maxwellthomastodosassignment2.api;

import com.maxwellthomastodosassignment2.api.models.Todo;

public interface TodoClickedListener {
    public void onClick(Todo todo);
}
