package com.maxwellthomastodosassignment2.api;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableArrayList;
import androidx.databinding.ObservableList;
import androidx.recyclerview.widget.RecyclerView;

import com.maxwellthomastodosassignment2.api.models.Todo;
import com.maxwellthomastodosassignment2.api.CustomAdapter;

public class TodoAdapter extends CustomAdapter<Todo> {
    TodoClickedListener listener;
    public TodoAdapter(ObservableArrayList<Todo> data, TodoClickedListener listener) {
        super(data);
        this.listener = listener;
    }

    @Override
    public int getLayout() {
        return R.layout.todo_list_item;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Todo todo = data.get(position);
        CheckBox taskNameDisplay = holder.getItemView().findViewById(R.id.todo);
        taskNameDisplay.setText(todo.task);
        //Change Button To Checkbox
        taskNameDisplay.setOnClickListener(view -> {
            listener.onClick(todo);
        });
    }
}
