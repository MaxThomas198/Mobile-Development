package com.maxwellthomastodosassignment2.api.viewmodels;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.ObservableArrayList;
import androidx.lifecycle.ViewModel;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.maxwellthomastodosassignment2.api.models.Todo;

public class TodosViewModel extends ViewModel {
    private ObservableArrayList<Todo> todos;
    private DatabaseReference db;
    public TodosViewModel() {
        db = FirebaseDatabase.getInstance().getReference();
    }

    public ObservableArrayList<Todo> getTodos() {
        if (todos == null) {
            todos = new ObservableArrayList<Todo>();
            loadContacts();
        }
        return todos;
    }

    private void loadContacts() {

        db.child("/todos").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Todo todo = snapshot.getValue(Todo.class);
                todo.id = snapshot.getKey();
                todos.add(todo);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Log.d("CHANGED", "A contact was changed");
                Todo todo = snapshot.getValue(Todo.class);
                todo.id = snapshot.getKey();
                int index = todos.indexOf(todo);
                todos.set(index, todo);
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                Todo todo = snapshot.getValue(Todo.class);
                todo.id = snapshot.getKey();
                todos.remove(todo);
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void addTodo(String task) {
        Todo newTodo = new Todo(task);
        db.child("/todos").push().setValue(newTodo);
    }

    public void updateTodo(String id, Boolean completed) {

        db.child("/todos").child(id).child("completed").setValue(completed);
    }




}
