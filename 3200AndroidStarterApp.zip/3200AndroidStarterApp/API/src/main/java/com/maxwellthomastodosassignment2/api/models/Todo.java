package com.maxwellthomastodosassignment2.api.models;

import androidx.annotation.Nullable;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Todo {
    public String task;
    public Boolean completed;



    @Exclude
    public String id;

    public Todo() {}

    public Todo(String task) {
        this.task = task;
        this.completed = false;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (obj instanceof Todo) {
            Todo other = (Todo) obj;
            return other.id.equals(id);
        }
        return false;
    }
}