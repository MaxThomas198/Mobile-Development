package com.maxwellthomastodosassignment2.watchapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.maxwellthomastodosassignment2.api.Verify;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.maxwellthomastodosassignment2.api.TodoAdapter;
import com.maxwellthomastodosassignment2.api.viewmodels.TodosViewModel;

public class MainActivity extends AppCompatActivity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView todosList = findViewById(R.id.todoList);
        TodosViewModel viewModel = new ViewModelProvider(this).get(TodosViewModel.class);

        TodoAdapter adapter = new TodoAdapter(viewModel.getTodos(), (todo) -> {
            Boolean changeState = !todo.completed;
            viewModel.updateTodo(todo.id, changeState);
        });

        todosList.setAdapter(adapter);
        todosList.setLayoutManager(new LinearLayoutManager(this));

    }
}