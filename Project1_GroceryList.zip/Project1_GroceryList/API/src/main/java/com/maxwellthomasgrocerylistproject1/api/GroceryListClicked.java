package com.maxwellthomasgrocerylistproject1.api;

import com.maxwellthomasgrocerylistproject1.api.models.GroceryList;

public interface GroceryListClicked {
    public void onClick(GroceryList groceryList);
}
